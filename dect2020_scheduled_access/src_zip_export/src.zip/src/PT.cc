#include <omnetpp.h>
#include <algorithm>
#include <deque>
#include <cstdint>
#include <vector>
#include <string>

#include "DectPacket_m.h"
#include "DectTypes.h"

using namespace omnetpp;


class PT : public cSimpleModule
{
  private:
    int id = -1;
    int cMin = 1;
    int cMax = 16;
    int currentCW = 1;
    bool forceZeroBackoff = false;
    bool useParityRandom = false;
    int paritySeed = 1;
    uint32_t backoffDrawCount = 0;
    simtime_t firstArrivalOffset = SIMTIME_ZERO;         // текущее значение C_i
    double arrProb = 0.01;
    simtime_t lbtTime = SIMTIME_ZERO;
    simtime_t ackTimeout = SIMTIME_ZERO;

    std::deque<DectPacket *> queue;   // пакеты, ожидающие отправки
    cMessage *arrivalTimer = nullptr;
    cMessage *backoffTimer = nullptr;
    cMessage *ackTimer = nullptr;
    bool waitingForAck = false;

    // статистика
    std::vector<int> firstDataStartTimes; // first 20 start times for parity replay
    long generatedPackets = 0;
    long dataAttempts = 0;
    long busyLbtResponses = 0;
    long acknowledgedPackets = 0;
    long retransmissions = 0;

  protected:
    void initialize() override;
    void handleMessage(cMessage *msg) override;
    void finish() override;

  private:
    void generatePacket();
    void startBackoff();
    void sendLbtRequest();
    void transmitCurrentPacket();
    void handleAck(DectPacket *ack);
    void handleAckTimeout();
    void increaseCW();
};

// Counter-based 32-bit PRNG also implemented in 4_random_access_shared_rng.py.
// Arrival draws are keyed by (PT, symbol), backoff draws by (PT, count).
static uint32_t parityHash(int kind, int id, uint32_t index, int seed) {
    uint32_t x = static_cast<uint32_t>(seed) * 0x9e3779b9u
               + static_cast<uint32_t>(id+1) * 0x85ebca6bu
               + (index+1u) * 0xc2b2ae35u
               + static_cast<uint32_t>(kind) * 0x27d4eb2fu;
    x ^= x >> 16; x *= 0x7feb352du;
    x ^= x >> 15; x *= 0x846ca68bu;
    x ^= x >> 16;
    return x;
}

Define_Module(PT);

void PT::initialize()
{
    id = par("id").intValue();
    arrProb = par("arrProb").doubleValue();
    cMin = par("cMin").intValue();
    cMax = par("cMax").intValue();
    forceZeroBackoff = par("forceZeroBackoff").boolValue();
    useParityRandom = par("useParityRandom").boolValue();
    paritySeed = par("paritySeed").intValue();
    firstArrivalOffset = par("firstArrivalOffset").doubleValueInUnit("s");
    lbtTime = par("lbtTime").doubleValueInUnit("s");
    ackTimeout = par("ackTimeout").doubleValueInUnit("s");

    if (arrProb < 0.0 || arrProb > 1.0)
        throw cRuntimeError("arrProb must be in [0,1], got %g", arrProb);
    if (cMin < 1 || cMax < cMin)
        throw cRuntimeError("Require 1 <= cMin <= cMax");

    currentCW = cMin;

    //первая проверка - в момент t=0
    arrivalTimer = new cMessage("arrivalTimer");
    scheduleAt(firstArrivalOffset, arrivalTimer);
}

void PT::handleMessage(cMessage *msg)
{
    //таймеры
    if (msg->isSelfMessage()) {
        if (msg == arrivalTimer) {
            const double arrivalDraw = useParityRandom
                ? static_cast<double>(parityHash(0,id,static_cast<uint32_t>(simTime().dbl()),paritySeed)) / 4294967296.0
                : uniform(0, 1);
            if (arrivalDraw < arrProb)
                generatePacket();
            scheduleAt(simTime() + 1.0, arrivalTimer); // 1 символ
            return;
        }
        if (msg == backoffTimer) {
            backoffTimer = nullptr;
            delete msg;
            sendLbtRequest();
            return;
        }
        if (msg == ackTimer) {
            ackTimer = nullptr;
            delete msg;
            handleAckTimeout();
            return;
        }
        delete msg;
        return;
    }

    //входящее сообщение от Medium
    DectPacket *packet = check_and_cast<DectPacket *>(msg);

    if (packet->getType() == MSG_LBT_RESPONSE) {
        if (packet->getChannelBusy()) {
            ++busyLbtResponses;
            EV_INFO << "LBT не пройден: канал ЗАНЯТ. Удваиваем CW.\n";
            increaseCW();
            if (!queue.empty() && !waitingForAck)
                startBackoff();
        }
        else if (!queue.empty() && !waitingForAck) {
            EV_INFO << "LBT пройден: канал СВОБОДЕН. Начинаем передачу.\n";
            transmitCurrentPacket();
        }
        delete packet;
        return;
    }

    if (packet->getType() == MSG_ACK_END) {
        handleAck(packet);
        delete packet;
        return;
    }

    delete packet;
}

void PT::generatePacket()
{
    auto *packet = new DectPacket("data");
    packet->setType(MSG_DATA);
    packet->setSrcId(id);
    packet->setPktId(static_cast<int>(generatedPackets));
    packet->setAttempt(0);
    packet->setGenTime(simTime());
    packet->setCollided(false);
    queue.push_back(packet);
    ++generatedPackets;
    EV_INFO << "Сгенерирован новый пакет #" << packet->getPktId() << ". Размер очереди: " << queue.size() << "\n";

    if (queue.size() == 1 && !waitingForAck && backoffTimer == nullptr)
        startBackoff();
}

void PT::startBackoff()
{
    if (queue.empty() || waitingForAck || backoffTimer != nullptr)
        return;

    // C_i = currentCW. Отсрочка x = U[0, C_i] * lbtTime.
    const int slots = forceZeroBackoff ? 0 : (useParityRandom
        ? static_cast<int>(parityHash(1,id,backoffDrawCount++,paritySeed) % static_cast<uint32_t>(currentCW+1))
        : intuniform(0, currentCW));
    backoffTimer = new cMessage("backoffTimer");
    scheduleAt(simTime() + slots * lbtTime, backoffTimer);
    EV_INFO << "Разыгрывается отсрочка (Backoff): CW = " << currentCW
            << ", выбрано слотов: " << slots
            << ", время ожидания: " << (slots * lbtTime) << "s\n";
}

void PT::sendLbtRequest()
{
    if (queue.empty() || waitingForAck)
        return;

    auto *request = new DectPacket("lbtRequest");
    request->setType(MSG_LBT_REQUEST);
    request->setSrcId(id);
    EV_INFO << "Отправка LBT-запроса (прослушивание канала на " << lbtTime << "s)\n";
    send(request, "out");
}

void PT::transmitCurrentPacket()
{
    if (queue.empty() || waitingForAck)
        return;

    DectPacket *packet = queue.front();
    packet->setAttempt(packet->getAttempt() + 1);
    packet->setCollided(false);

    auto *copy = packet->dup();
    copy->setType(MSG_DATA);
    ++dataAttempts;
    if (firstDataStartTimes.size() < 20)
        firstDataStartTimes.push_back(static_cast<int>(simTime().dbl()));
    send(copy, "out");

    EV_INFO << "Начата передача пакета #" << packet->getPktId()<< " (попытка " << packet->getAttempt() << ")\n";

    waitingForAck = true;
    ackTimer = new cMessage("ackTimer");
    // OMNeT++ lower scheduling priority value executes FIRST.  At the
    // exact Python ACK boundary (25 symbols), let Medium's ACK_END and
    // the resulting PT message run before this timeout (priority +1).
    ackTimer->setSchedulingPriority(1);
    scheduleAt(simTime() + ackTimeout, ackTimer);
}

void PT::handleAck(DectPacket *ack)
{
    // отбрасываем «чужие», устаревшие и коллидированные ACK
    if (ack->getDstId() != id || ack->getCollided() || queue.empty() || !waitingForAck)
        return;

    DectPacket *current = queue.front();
    if (ack->getPktId() != current->getPktId()
        || ack->getSrcId() != id
        || ack->getAttempt() != current->getAttempt())
        return;
    EV_INFO << "Получен ACK для пакета #" << ack->getPktId() << ". Успех! CW сброшен до " << cMin << "\n";
    waitingForAck = false;
    if (ackTimer != nullptr) {
        cancelAndDelete(ackTimer);
        ackTimer = nullptr;
    }

    retransmissions += std::max(0, current->getAttempt() - 1);
    ++acknowledgedPackets;
    delete queue.front();
    queue.pop_front();

    //успешная передача - CW сбрасывается
    currentCW = cMin;

    if (!queue.empty())
        startBackoff();
}

void PT::handleAckTimeout()
{
    if (!waitingForAck)
        return;// ACK уже пришёл, таймер просто «просрочен»
    waitingForAck = false;

    if (queue.empty())
        return;//на всякий случай

    // Неуспех: увеличиваем CW и снова backoff
    EV_WARN << "ТАЙМАУТ ACK для пакета #" << queue.front()->getPktId()<< ". ACK не пришел, удваиваем CW и повторяем.\n";
    increaseCW();
    startBackoff();
}

void PT::increaseCW()
{
    currentCW = std::min(cMax, std::max(cMin, 2 * currentCW));
}

void PT::finish()
{
    cancelAndDelete(arrivalTimer);
    if (backoffTimer != nullptr) cancelAndDelete(backoffTimer);
    if (ackTimer != nullptr)     cancelAndDelete(ackTimer);

    recordScalar("generatedPackets",        generatedPackets);
    for (size_t i=0; i<firstDataStartTimes.size(); ++i)
        recordScalar(("txStart"+std::to_string(i)).c_str(), firstDataStartTimes[i]);
    recordScalar("dataTransmissionAttempts", dataAttempts);
    recordScalar("busyLbtResponses",         busyLbtResponses);
    recordScalar("acknowledgedPackets",      acknowledgedPackets);
    recordScalar("dataRetransmissions",      retransmissions);
    recordScalar("queueLengthAtEnd",         static_cast<double>(queue.size()));

    for (auto *p : queue) delete p;
    queue.clear();
}
